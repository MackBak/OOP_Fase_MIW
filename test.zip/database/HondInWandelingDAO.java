package database;

import model.Wandeling;
import model.Hond;

import java.sql.SQLException;

public class HondInWandelingDAO extends AbstractDAO {

    public HondInWandelingDAO(DBaccess dBaccess) {
        super(dBaccess);
    }

    public void slaHondenInWandelingOp(Wandeling wandeling) {
        String sqlInWandeling = "INSERT INTO HondInWandeling VALUES (?, ?)";
        try {
            setupPreparedStatement(sqlInWandeling);
            preparedStatement.setInt(1, wandeling.getWandelingId());
            for (Hond hond : wandeling.getHonden()) {
                preparedStatement.setString(2, hond.getChipnummer());
                executeManipulateStatement();
            }
        } catch (SQLException sqlRuntime) {
            System.out.println("Error in slaHondenInWandelingOp: " + sqlRuntime);
        }
    }
}
