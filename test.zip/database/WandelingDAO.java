package database;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Hond;
import model.Klant;
import model.Wandeling;
import model.Medewerker;

public class WandelingDAO extends AbstractDAO {

    public WandelingDAO(DBaccess dBaccess) {
        super(dBaccess);
    }


    public void slaWandelingOp(Wandeling wandeling) {
        String sqlWandelingImport = "INSERT INTO wandeling (wandelingId, datum, duur, medewerkercode) VALUES (?,?,?,?)";
        try {
            setupPreparedStatement(sqlWandelingImport);
            preparedStatement.setInt(1, wandeling.getWandelingId());
            preparedStatement.setObject(2, wandeling.getUitlaatDatum());
            preparedStatement.setDouble(3, wandeling.getDuur());
            preparedStatement.setString(4, wandeling.getUitlaatMedewerker().getMedewerkerCode());
            executeManipulateStatement();

        } catch (SQLException sqlExceptionError) {
            System.out.println("Error in slaWandelingOp: " + sqlExceptionError.getMessage());
        }
    }
}
