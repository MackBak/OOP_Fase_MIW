package database;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Klant;

public class KlantDAO extends AbstractDAO {


	public KlantDAO(DBaccess dBaccess) {
		super(dBaccess);
	}


	public List<Klant> getKlanten() {
		List<Klant> klantenLijst = new ArrayList<>();
		String sql = "SELECT * FROM Klant";
		Klant klant;
		try {
			setupPreparedStatement(sql);
			ResultSet resultSet = executeSelectStatement();
			while (resultSet.next()) {
				int klantnummer = resultSet.getInt("klantnummer");
				String voorletters = resultSet.getString("voorletters");
				String tussenvoegsel = resultSet.getString("tussenvoegsel");
				String achternaam = resultSet.getString("achternaam");
				String telefoon = resultSet.getString("telefoon");
				klant = new Klant(klantnummer, voorletters, tussenvoegsel, achternaam, telefoon);
				klantenLijst.add(klant);
			}
		} catch (SQLException sqlFout) {
			System.out.println("SQL fout " + sqlFout.getMessage());
		}
		return klantenLijst;
	}


	public void slaKlantOp(Klant klant) {
		String sql = "INSERT INTO klant (klantnummer, voorletters, tussenvoegsel, achternaam, telefoon) VALUES (?, ?, ?, ?, ?)";
		try {
			setupPreparedStatement(sql);
			preparedStatement.setInt(1, klant.getKlantnummer());
			preparedStatement.setString(2, klant.getVoorletters());
			preparedStatement.setString(3, klant.getTussenvoegsel());
			preparedStatement.setString(4, klant.getAchternaam());
			preparedStatement.setString(5, klant.getTelefoon());
			executeManipulateStatement();
		} catch (SQLException error) {
			System.out.println("Error in slaKlantOp: " + error.getMessage());
		}
	}

	public Klant getKlantPerId(int klantId) {
		String selectSql = "SELECT * FROM klant WHERE klantnummer = ?;";
		Klant klant = null;
		try {
			setupPreparedStatement(selectSql);
			preparedStatement.setInt(1, klantId); // Zet de klantId parameter
			ResultSet resultSet = executeSelectStatement();
			if (resultSet.next()) {
				int klantnummer = resultSet.getInt("klantnummer");
				String voorletters = resultSet.getString("voorletters");
				String tussenvoegsel = resultSet.getString("tussenvoegsel");
				String achternaam = resultSet.getString("achternaam");
				String telefoon = resultSet.getString("telefoon");

				klant = new Klant(klantnummer, voorletters, tussenvoegsel, achternaam, telefoon);
			}
		} catch (SQLException error) {
			System.out.println("Error in getKlantPerId: " + error.getMessage());
		}
		return klant;
	}
}
