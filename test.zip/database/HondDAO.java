package database;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Hond;
import model.Klant;

public class HondDAO extends AbstractDAO {


    public HondDAO(DBaccess dBaccess) {
        super(dBaccess);
    }

    public void slaHondOp(Hond hond) {
        String sqlImport = "INSERT INTO hond (chipnummer, hondnaam, ras, klantnummer) VALUES (?, ?, ?, ?)";
        try {
            setupPreparedStatement(sqlImport);
            preparedStatement.setString(1, hond.getChipnummer());
            preparedStatement.setString(2, hond.getNaam());
            preparedStatement.setString(3, hond.getRas());
            preparedStatement.setInt(4, hond.getEigenaar().getKlantnummer());
            executeManipulateStatement();

        } catch (SQLException SqlError) {
            System.out.println("Error in slaHondOp: " + SqlError.getMessage());
        }
    }//end of slaHondOp


    public Hond getHondPerId(String chipnummer) {
        String sqlHondSelect = "SELECT * FROM hond WHERE chipnummer = ?;";
        Hond hond = null;
        KlantDAO klantDAO = new KlantDAO(dBaccess); //Object klantDAO aanmaken om gegevens hier uit te halen. In dit geval is natuurlijk klant nodig.

        try {
            setupPreparedStatement(sqlHondSelect);
            preparedStatement.setString(1, chipnummer);
            ResultSet resultSet = executeSelectStatement();
            if (resultSet.next()) {
                String chipnummer2 = resultSet.getString("chipnummer");
                String naam2 = resultSet.getString("hondnaam");
                String ras2 = resultSet.getString("ras");
                int klantnummer = resultSet.getInt("klantnummer");
                Klant klant = klantDAO.getKlantPerId(klantnummer);

                hond = new Hond(chipnummer2, naam2, ras2, klant);
            }

        } catch (SQLException sqlRuntime) {
            System.out.println("Error in getHondPerID: " + sqlRuntime.getMessage());
        }

        return hond;
    }

    public List<Hond> getHondenPerKlant(Klant klant) {
        String sqlHondKlant = "SELECT * FROM hond WHERE klantnummer = ?;";
        List<Hond> hondenPerKlant = new ArrayList<>();
        Hond hond = null;

        try {
            setupPreparedStatement(sqlHondKlant); //PreparedStatement als bescherming tegen SQL-Injecties en de SQL statement voor te bereiden.
            preparedStatement.setInt(1, klant.getKlantnummer()); //Hier vul ik de PreparedStatement in met values. Op = ? komt dus (door 1 naar 1e ?) de waarde van klant.getKlantnummer.
            ResultSet resultSet = executeSelectStatement(); //Hiermee wordt de SQL-Query uitgevoerd en de resultaten wordt opgeslagen in het resultSet object.

            while (resultSet.next()) { //While loop die blijft lopen zolang er nog resultaten zijn in de ResultSet
                //Met onderstaande worden de waardes opgehaald en worden toegevoegd aan de attributen die ik declareer.
                String chipnummer = resultSet.getString("chipnummer");
                String naam = resultSet.getString("hondnaam");
                String ras = resultSet.getString("ras");

                hond = new Hond(chipnummer, naam, ras, klant); //Maakt een nieuw hond object aan met de opgehaalde gegevens van hierboven.
                hondenPerKlant.add(hond); //Nieuwe gemaakte hond object wordt toegevoegd aan de ArrayList.
            }
        } catch (SQLException sqlException) { //Verplichte Catch om fout af te handelen.
            System.out.println("Error in getHondenPerKlant: " + sqlException.getMessage());
        }
        return hondenPerKlant; //Returnt de gemaakte ArrayList.
    }

    public List<Hond> getHonden() {
        String sqlAlleHonden = "SELECT * FROM hond;";
        List<Hond> alleHonden = new ArrayList<>();
        KlantDAO klantDAO = new KlantDAO(dBaccess); //Object klantDAO aanmaken om gegevens hier uit te halen. In dit geval is natuurlijk klant nodig.
        Hond hond = null;

        try {
            setupPreparedStatement(sqlAlleHonden);
            ResultSet resultSet = executeSelectStatement();
            while (resultSet.next()) {
                String chipnummer = resultSet.getString("chipnummer");
                String naam = resultSet.getString("hondnaam");
                String ras = resultSet.getString("ras");
                int klantnummer = resultSet.getInt("klantnummer");
                Klant klant3 = klantDAO.getKlantPerId(klantnummer);

                hond = new Hond(chipnummer, naam, ras, klant3);

                alleHonden.add(hond);
            }

        } catch (SQLException sqlException) {
            System.out.println("Error in getHonden: " + sqlException.getMessage());
        }
        return alleHonden;
    }
}
